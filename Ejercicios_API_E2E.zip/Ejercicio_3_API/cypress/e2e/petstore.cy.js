describe('Flujo CRUD de usuarios en PetStore', () => {
  const baseUrl = 'https://petstore.swagger.io/v2';
  const username = 'michael_test';
  
  it('Crear un usuario', () => {
    cy.request('POST', `${baseUrl}/user`, {
      id: 1,
      username: username,
      firstName: 'Michael',
      lastName: 'Padilla',
      email: 'michael@test.com',
      password: '12345',
      phone: '99999999',
      userStatus: 1
    }).then((response) => {
      expect(response.status).to.eq(200);
    });
  });

  it('Buscar el usuario creado', () => {
    cy.request('GET', `${baseUrl}/user/${username}`).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body.username).to.eq(username);
    });
  });

  it('Actualizar el nombre y correo del usuario', () => {
    cy.request('PUT', `${baseUrl}/user/${username}`, {
      id: 1,
      username: username,
      firstName: 'Miguel',
      lastName: 'Padilla',
      email: 'miguel@test.com',
      password: '12345',
      phone: '99999999',
      userStatus: 1
    }).then((response) => {
      expect(response.status).to.eq(200);
    });
  });

  it('Buscar el usuario actualizado', () => {
    cy.request('GET', `${baseUrl}/user/${username}`).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body.firstName).to.eq('Miguel');
      expect(response.body.email).to.eq('miguel@test.com');
    });
  });

  it('Eliminar el usuario', () => {
    cy.request('DELETE', `${baseUrl}/user/${username}`).then((response) => {
      expect(response.status).to.eq(200);
    });
  });
});
