# Instrucciones para ejecutar la prueba E2E en Cypress

## Requisitos previos
- Tener instalado Node.js (versión LTS recomendada)
- Tener instalado Visual Studio Code

## Pasos para ejecutar

1. Clonar el repositorio desde GitHub:
   git clone https://github.com/tu-usuario/saucedemo-e2e.git

2. Abrir la carpeta del proyecto en Visual Studio Code.

3. Instalar las dependencias:
   npm install

4. Ejecutar Cypress en modo interactivo:
   npx cypress open

5. Seleccionar el archivo de prueba:
   cypress/e2e/saucedemo.cy.js

6. Ejecutar el test "Flujo completo de compra en Saucedemo"

## Notas
- El test automatiza el flujo completo de compra en https://www.saucedemo.com
- Se utiliza el usuario: `standard_user` y contraseña: `secret_sauce`
- El flujo incluye login, agregar productos, visualizar carrito, checkout y confirmación final.
