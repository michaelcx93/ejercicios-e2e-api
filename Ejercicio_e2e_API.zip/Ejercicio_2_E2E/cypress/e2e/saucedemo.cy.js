describe('Flujo completo de compra en Saucedemo', () => {
  it('Login, agregar productos, checkout y finalizar compra', () => {
    cy.visit('https://www.saucedemo.com/');
    cy.get('#user-name').type('standard_user');
    cy.get('#password').type('secret_sauce');
    cy.get('#login-button').click();
    cy.url().should('include', '/inventory.html');

    // Agregar productos
    cy.get('#add-to-cart-sauce-labs-backpack').should('be.visible').click();
    cy.get('#add-to-cart-sauce-labs-bike-light').should('be.visible').click();
    cy.get('.shopping_cart_badge').should('contain', '2');

    // Visualizar carrito
    cy.get('.shopping_cart_link').should('be.visible').click();
    cy.url().should('include', '/cart.html');
    cy.get('.cart_item').should('have.length', 2);

    // Checkout
    cy.get('#checkout').should('be.visible').click();
    cy.url().should('include', '/checkout-step-one.html');
    cy.get('#first-name').type('Michael');
    cy.get('#last-name').type('Padilla');
    cy.get('#postal-code').type('11101');
    cy.get('#continue').should('be.visible').click();
    cy.url().should('include', '/checkout-step-two.html');

    // Finalizar compra
    cy.get('#finish').should('be.visible').click();
    cy.url().should('include', '/checkout-complete.html');
    cy.get('.complete-header', { timeout: 10000 }).should('contain', 'THANK YOU FOR YOUR ORDER');
  });
});
