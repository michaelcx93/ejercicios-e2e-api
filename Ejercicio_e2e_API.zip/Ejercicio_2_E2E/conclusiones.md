# Conclusiones del ejercicio E2E

Durante la ejecución del flujo completo de compra en Saucedemo se identificaron los siguientes hallazgos:

1. El login se realiza correctamente y redirige a la página de inventario.
2. Los productos se agregan al carrito y se visualizan correctamente.
3. El formulario de checkout se completa sin errores y permite avanzar al paso final.
4. La validación final del mensaje "THANK YOU FOR YOUR ORDER" falla por timeout, aunque la URL sí cambia a /checkout-complete.html.

Posibles causas del fallo:
- El elemento <h2.complete-header> tarda más de lo esperado en renderizarse.
- Cypress no detecta el texto a tiempo, a pesar de que la página se carga.
- El backend de Saucedemo puede tener latencia o comportamiento simulado que afecta la sincronización.

Recomendaciones:
- Aumentar el timeout en la validación final.
- Validar que el elemento exista antes de verificar su contenido.
- Considerar dividir el flujo en pasos con persistencia de estado si se desea mayor control.

Resultado final:
- El test falla en la última validación, pero el flujo completo se ejecuta correctamente hasta la confirmación de compra.
