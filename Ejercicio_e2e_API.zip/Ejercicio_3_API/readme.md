# Instrucciones de ejecución - Ejercicio 3 API (PetStore)

## Requisitos previos
- Node.js instalado (versión LTS recomendada).
- Visual Studio Code o cualquier editor de texto.
- Cypress instalado como dependencia del proyecto.

## Pasos de instalación
1. Clonar el repositorio desde GitHub:
   git clone https://github.com/usuario/Ejercicio_3_API.git

2. Entrar a la carpeta del proyecto:
   cd Ejercicio_3_API

3. Instalar las dependencias:
   npm install

## Ejecución de pruebas

### Modo interactivo
1. Ejecutar:
   npx cypress open
2. Seleccionar **E2E Testing**.
3. Elegir el navegador.
4. Seleccionar el archivo `cypress/e2e/petstore.cy.js` y ejecutar las pruebas.

### Modo headless (sin interfaz gráfica)
Ejecutar directamente en la terminal:
   npx cypress run --spec "cypress/e2e/petstore.cy.js"

## Resultados esperados
- Se ejecutan 5 pruebas:
  1. Crear un usuario.
  2. Buscar el usuario creado.
  3. Actualizar nombre y correo.
  4. Buscar el usuario actualizado.
  5. Eliminar el usuario.
- Todas las pruebas deben pasar con status 200.
